# Reproduce fig2 of soNNia paper

Step 0: Download emerson files from https://clients.adaptivebiotech.com/pub/emerson-2017-natgen 

Step1: put all emerson files in the emerson-nat directory

Step2: pip install sonnia (and possibly other dependencies that are missing)

Step3: python fig2_process_data.py

Step4: python fig2_infer.py

Step5: python fig2_evaluate.py

Step6: python fig2_plot.py